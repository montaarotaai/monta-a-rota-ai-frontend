# 🚀 Monta a Rota Aí — Backend API

## Como subir no Railway (GRATUITO, sem cartão)

### Passo 1 — Colocar código no GitHub
1. Acesse **github.com** e crie uma conta (se não tiver)
2. Clique em **"New repository"**
3. Nome: `monta-a-rota-ai-backend`
4. Clique em **"Create repository"**
5. Na próxima tela, clique em **"uploading an existing file"**
6. Arraste TODOS os arquivos desta pasta para lá
7. Clique em **"Commit changes"**

### Passo 2 — Subir no Railway
1. Acesse **railway.app**
2. Clique em **"Start a New Project"**
3. Escolha **"Deploy from GitHub repo"**
4. Conecte sua conta GitHub e selecione o repositório criado
5. Railway vai detectar automaticamente que é Node.js ✅

### Passo 3 — Configurar variáveis de ambiente
No Railway, vá em **Variables** e adicione:

```
SUPABASE_URL = https://XXXX.supabase.co
SUPABASE_SERVICE_KEY = eyJhbGci...  (Service Role Key do Supabase)
JWT_SECRET = qualquer_texto_longo_e_secreto_aqui
PORT = 3000
NODE_ENV = production
GOOGLE_MAPS_KEY = AIza...  (opcional por enquanto)
```

**Onde pegar as chaves do Supabase:**
- Supabase → seu projeto → Settings → API
- Copie: `URL` e `service_role` (não o anon!)

### Passo 4 — Pegar a URL do seu backend
- No Railway, vá em **Settings → Domains**
- Clique em **"Generate Domain"**
- Você receberá uma URL tipo: `https://monta-a-rota-ai-backend.up.railway.app`
- **Guarde essa URL** — ela será usada no dashboard e no app

### Teste rápido
Acesse no navegador: `https://SUA-URL.up.railway.app/`
Deve aparecer:
```json
{
  "sistema": "🚀 Monta a Rota Aí - API",
  "status": "online"
}
```

---

## Endpoints da API

### Autenticação
- `POST /api/auth/login` — fazer login
- `POST /api/auth/cadastrar` — criar usuário

### Pedidos
- `GET /api/pedidos` — listar pedidos
- `POST /api/pedidos` — criar pedido
- `PATCH /api/pedidos/:id/status` — atualizar status
- `POST /api/pedidos/:id/confirmar` — confirmar entrega (código anti-fraude)
- `GET /api/pedidos/alertas/atraso` — pedidos atrasados

### Rotas
- `POST /api/rotas/montar` — criar rota otimizada
- `GET /api/rotas` — listar rotas
- `PATCH /api/rotas/:id/iniciar` — iniciar rota
- `PATCH /api/rotas/:id/concluir` — concluir rota

### Entregadores
- `GET /api/entregadores` — listar
- `GET /api/entregadores/disponiveis` — disponíveis
- `POST /api/entregadores` — cadastrar
- `PATCH /api/entregadores/:id/gps` — atualizar GPS
- `PATCH /api/entregadores/:id/status` — mudar status

### Lojas
- `GET /api/lojas` — listar
- `POST /api/lojas` — cadastrar
- `PUT /api/lojas/:id` — editar

### Financeiro
- `GET /api/pagamentos` — listar pagamentos
- `POST /api/pagamentos/gerar-semanal` — gerar cobrança semanal
- `PATCH /api/pagamentos/:id/pagar` — registrar pagamento

### Analytics
- `GET /api/analytics/resumo/:loja_id` — resumo + sugestões

---

## Tecnologias
- **Node.js** + Express
- **Supabase** (PostgreSQL)
- **JWT** para autenticação
- **Railway** para hospedagem gratuita
