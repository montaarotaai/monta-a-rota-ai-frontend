const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const supabase = require('../config/supabase');

// POST /api/auth/login
router.post('/login', async (req, res) => {
  try {
    const { email, senha } = req.body;
    if (!email || !senha) return res.status(400).json({ erro: 'Email e senha obrigatórios' });

    const { data: usuario, error } = await supabase
      .from('usuarios')
      .select('*')
      .eq('email', email.toLowerCase())
      .eq('status', 'ativo')
      .single();

    if (error || !usuario) return res.status(401).json({ erro: 'Usuário não encontrado' });

    const senhaOk = await bcrypt.compare(senha, usuario.senha_hash);
    if (!senhaOk) return res.status(401).json({ erro: 'Senha incorreta' });

    // Atualiza último login
    await supabase.from('usuarios').update({ ultimo_login_at: new Date() }).eq('id', usuario.id);

    const token = jwt.sign(
      { id: usuario.id, email: usuario.email, papel: usuario.papel, loja_id: usuario.loja_id },
      process.env.JWT_SECRET,
      { expiresIn: '30d' }
    );

    res.json({
      token,
      usuario: {
        id: usuario.id,
        nome: usuario.nome,
        email: usuario.email,
        papel: usuario.papel,
        loja_id: usuario.loja_id,
        entregador_id: usuario.entregador_id
      }
    });
  } catch (e) {
    res.status(500).json({ erro: e.message });
  }
});

// POST /api/auth/cadastrar (apenas super_admin pode criar usuários)
router.post('/cadastrar', async (req, res) => {
  try {
    const { nome, email, senha, papel, loja_id, entregador_id } = req.body;
    if (!nome || !email || !senha) return res.status(400).json({ erro: 'Dados obrigatórios faltando' });

    const senha_hash = await bcrypt.hash(senha, 10);

    const { data, error } = await supabase.from('usuarios').insert({
      nome, email: email.toLowerCase(), senha_hash, papel: papel || 'loja',
      loja_id: loja_id || null, entregador_id: entregador_id || null
    }).select().single();

    if (error) return res.status(400).json({ erro: error.message });
    res.status(201).json({ mensagem: 'Usuário criado', id: data.id });
  } catch (e) {
    res.status(500).json({ erro: e.message });
  }
});

module.exports = router;
