const express = require('express');
const router = express.Router();
const supabase = require('../config/supabase');
const auth = require('../middleware/auth');

// GET /api/entregadores - lista todos
router.get('/', auth, async (req, res) => {
  try {
    const { status } = req.query;
    let query = supabase.from('entregadores').select('*').order('nome');
    if (status) query = query.eq('status', status);
    const { data, error } = await query;
    if (error) return res.status(400).json({ erro: error.message });
    res.json(data);
  } catch (e) {
    res.status(500).json({ erro: e.message });
  }
});

// GET /api/entregadores/disponiveis - apenas disponíveis (para atribuir pedido)
router.get('/disponiveis', auth, async (req, res) => {
  try {
    const { data, error } = await supabase
      .from('entregadores')
      .select('id, nome, telefone, veiculo, avaliacao_media, lat_atual, lng_atual')
      .eq('status', 'disponivel')
      .order('avaliacao_media', { ascending: false });
    if (error) return res.status(400).json({ erro: error.message });
    res.json(data);
  } catch (e) {
    res.status(500).json({ erro: e.message });
  }
});

// GET /api/entregadores/:id
router.get('/:id', auth, async (req, res) => {
  try {
    const { data, error } = await supabase
      .from('entregadores').select('*').eq('id', req.params.id).single();
    if (error) return res.status(404).json({ erro: 'Entregador não encontrado' });
    res.json(data);
  } catch (e) {
    res.status(500).json({ erro: e.message });
  }
});

// POST /api/entregadores - cadastrar
router.post('/', auth, async (req, res) => {
  try {
    const { nome, cpf, telefone, email, veiculo, placa, cnh, chave_pix } = req.body;
    if (!nome || !telefone) return res.status(400).json({ erro: 'Nome e telefone obrigatórios' });
    const { data, error } = await supabase.from('entregadores').insert({
      nome, cpf, telefone, email, veiculo: veiculo || 'moto', placa, cnh, chave_pix
    }).select().single();
    if (error) return res.status(400).json({ erro: error.message });
    res.status(201).json(data);
  } catch (e) {
    res.status(500).json({ erro: e.message });
  }
});

// PATCH /api/entregadores/:id/gps - atualizar posição GPS (chamado pelo app do entregador)
router.patch('/:id/gps', async (req, res) => {
  try {
    const { lat, lng, velocidade_kmh, precisao_m } = req.body;
    if (!lat || !lng) return res.status(400).json({ erro: 'Lat e Lng obrigatórios' });

    // Atualiza posição atual
    await supabase.from('entregadores').update({
      lat_atual: lat, lng_atual: lng, ultimo_gps_at: new Date().toISOString()
    }).eq('id', req.params.id);

    // Salva histórico de GPS
    await supabase.from('rastreamento_gps').insert({
      entregador_id: req.params.id, lat, lng, velocidade_kmh, precisao_m
    });

    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ erro: e.message });
  }
});

// PATCH /api/entregadores/:id/status
router.patch('/:id/status', auth, async (req, res) => {
  try {
    const { status } = req.body;
    const validos = ['disponivel', 'em_rota', 'offline', 'bloqueado'];
    if (!validos.includes(status)) return res.status(400).json({ erro: 'Status inválido' });
    const { data, error } = await supabase
      .from('entregadores').update({ status }).eq('id', req.params.id).select().single();
    if (error) return res.status(400).json({ erro: error.message });
    res.json(data);
  } catch (e) {
    res.status(500).json({ erro: e.message });
  }
});

module.exports = router;
