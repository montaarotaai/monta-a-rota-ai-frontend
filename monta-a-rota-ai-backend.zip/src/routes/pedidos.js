const express = require('express');
const router = express.Router();
const supabase = require('../config/supabase');
const auth = require('../middleware/auth');
const { gerarCodigoConfirmacao, calcularPrevisaoEntrega, verificarRiscoAtraso } = require('../utils/helpers');

// GET /api/pedidos - lista pedidos (com filtros)
router.get('/', auth, async (req, res) => {
  try {
    const { status, loja_id, entregador_id, data, limit = 50 } = req.query;

    let query = supabase
      .from('pedidos')
      .select(`*, lojas(nome), entregadores(nome, telefone)`)
      .order('created_at', { ascending: false })
      .limit(parseInt(limit));

    if (status)        query = query.eq('status', status);
    if (loja_id)       query = query.eq('loja_id', loja_id);
    if (entregador_id) query = query.eq('entregador_id', entregador_id);
    if (data)          query = query.gte('created_at', `${data}T00:00:00`).lte('created_at', `${data}T23:59:59`);

    // Loja só vê seus próprios pedidos
    if (req.usuario.papel === 'loja') query = query.eq('loja_id', req.usuario.loja_id);

    const { data: pedidos, error } = await query;
    if (error) return res.status(400).json({ erro: error.message });

    res.json(pedidos);
  } catch (e) {
    res.status(500).json({ erro: e.message });
  }
});

// GET /api/pedidos/:id - detalhe de um pedido
router.get('/:id', auth, async (req, res) => {
  try {
    const { data, error } = await supabase
      .from('pedidos')
      .select(`*, lojas(nome, telefone, endereco), entregadores(nome, telefone, lat_atual, lng_atual)`)
      .eq('id', req.params.id)
      .single();

    if (error) return res.status(404).json({ erro: 'Pedido não encontrado' });
    res.json(data);
  } catch (e) {
    res.status(500).json({ erro: e.message });
  }
});

// POST /api/pedidos - criar novo pedido
router.post('/', auth, async (req, res) => {
  try {
    const {
      loja_id, cliente_nome, cliente_telefone, cliente_endereco,
      cliente_bairro, cliente_cidade, cliente_cep, cliente_complemento,
      itens, valor_pedido, forma_pagamento, troco_para,
      tempo_preparo_min, observacoes, origem
    } = req.body;

    if (!cliente_endereco) return res.status(400).json({ erro: 'Endereço do cliente obrigatório' });

    const codigo_confirmacao = gerarCodigoConfirmacao();
    const previsao_entrega = calcularPrevisaoEntrega(tempo_preparo_min || 20);
    const taxa_plataforma = 4.50; // taxa fixa

    const { data, error } = await supabase.from('pedidos').insert({
      loja_id: loja_id || req.usuario.loja_id,
      cliente_nome, cliente_telefone, cliente_endereco,
      cliente_bairro, cliente_cidade, cliente_cep, cliente_complemento,
      itens, valor_pedido, forma_pagamento, troco_para,
      taxa_plataforma, codigo_confirmacao, previsao_entrega,
      tempo_preparo_min: tempo_preparo_min || 20,
      observacoes, origem: origem || 'manual',
      status: 'pendente'
    }).select().single();

    if (error) return res.status(400).json({ erro: error.message });

    res.status(201).json({
      ...data,
      mensagem: '✅ Pedido criado com sucesso',
      codigo_confirmacao
    });
  } catch (e) {
    res.status(500).json({ erro: e.message });
  }
});

// PATCH /api/pedidos/:id/status - atualizar status do pedido
router.patch('/:id/status', auth, async (req, res) => {
  try {
    const { status } = req.body;
    const statusValidos = ['pendente','aceito','coletado','em_rota','entregue','cancelado','problema'];
    if (!statusValidos.includes(status)) return res.status(400).json({ erro: 'Status inválido' });

    const campos = { status };
    const agora = new Date().toISOString();

    // Registra timestamp de cada etapa
    if (status === 'aceito')    campos.aceito_em = agora;
    if (status === 'coletado')  campos.coletado_em = agora;
    if (status === 'entregue')  campos.entregue_em = agora;
    if (status === 'cancelado') campos.cancelado_em = agora;

    const { data, error } = await supabase
      .from('pedidos').update(campos).eq('id', req.params.id).select().single();

    if (error) return res.status(400).json({ erro: error.message });
    res.json({ mensagem: `Status atualizado para: ${status}`, pedido: data });
  } catch (e) {
    res.status(500).json({ erro: e.message });
  }
});

// POST /api/pedidos/:id/confirmar - cliente confirma entrega com código
router.post('/:id/confirmar', async (req, res) => {
  try {
    const { codigo } = req.body;

    const { data: pedido, error } = await supabase
      .from('pedidos').select('*').eq('id', req.params.id).single();

    if (error || !pedido) return res.status(404).json({ erro: 'Pedido não encontrado' });
    if (pedido.codigo_confirmacao !== codigo) return res.status(400).json({ erro: '❌ Código inválido' });
    if (pedido.confirmado_em) return res.status(400).json({ erro: 'Pedido já confirmado' });

    await supabase.from('pedidos').update({
      confirmado_em: new Date().toISOString(),
      status: 'entregue'
    }).eq('id', req.params.id);

    // Atualiza contador do entregador
    if (pedido.entregador_id) {
      const { data: ent } = await supabase.from('entregadores').select('total_entregas, saldo').eq('id', pedido.entregador_id).single();
      if (ent) {
        await supabase.from('entregadores').update({
          total_entregas: (ent.total_entregas || 0) + 1,
          saldo: (ent.saldo || 0) + (pedido.taxa_plataforma || 4.50)
        }).eq('id', pedido.entregador_id);
      }
    }

    res.json({ mensagem: '✅ Entrega confirmada com sucesso!' });
  } catch (e) {
    res.status(500).json({ erro: e.message });
  }
});

// GET /api/pedidos/alertas/atraso - lista pedidos em risco de atraso
router.get('/alertas/atraso', auth, async (req, res) => {
  try {
    const agora = new Date();
    const { data: pedidos } = await supabase
      .from('pedidos')
      .select('*, entregadores(nome, telefone), lojas(nome)')
      .in('status', ['pendente', 'aceito', 'coletado', 'em_rota'])
      .lt('previsao_entrega', agora.toISOString());

    res.json(pedidos || []);
  } catch (e) {
    res.status(500).json({ erro: e.message });
  }
});

module.exports = router;
