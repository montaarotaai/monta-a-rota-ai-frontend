const { pagamentosRouter } = require('./outros');
module.exports = pagamentosRouter;
