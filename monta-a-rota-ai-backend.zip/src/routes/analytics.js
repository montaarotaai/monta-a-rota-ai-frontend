const { analyticsRouter } = require('./outros');
module.exports = analyticsRouter;
