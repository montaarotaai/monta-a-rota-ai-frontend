const express = require('express');
const router = express.Router();
const supabase = require('../config/supabase');
const auth = require('../middleware/auth');
const axios = require('axios');

// Monta link do Google Maps com múltiplos destinos em ordem
function montarLinkGoogleMaps(origem, destinos) {
  const base = 'https://www.google.com/maps/dir/';
  const pontos = [origem, ...destinos].map(d => encodeURIComponent(d)).join('/');
  return `${base}${pontos}`;
}

// Monta link do Waze com o primeiro destino
function montarLinkWaze(destino) {
  return `https://waze.com/ul?q=${encodeURIComponent(destino)}&navigate=yes`;
}

// Algoritmo simples de otimização por proximidade (Nearest Neighbor)
function otimizarOrdem(pedidos) {
  if (pedidos.length <= 1) return pedidos;
  // Por enquanto retorna na ordem recebida
  // Em versão futura usa Google Maps Distance Matrix API
  return pedidos;
}

// POST /api/rotas/montar - monta rota otimizada para um entregador
router.post('/montar', auth, async (req, res) => {
  try {
    const { entregador_id, pedidos_ids, loja_endereco } = req.body;

    if (!entregador_id || !pedidos_ids?.length) {
      return res.status(400).json({ erro: 'entregador_id e pedidos_ids obrigatórios' });
    }

    // Busca os pedidos
    const { data: pedidos, error } = await supabase
      .from('pedidos').select('*').in('id', pedidos_ids);
    if (error) return res.status(400).json({ erro: error.message });

    const pedidosOrdenados = otimizarOrdem(pedidos);
    const destinos = pedidosOrdenados.map(p => p.cliente_endereco);

    const linkGoogleMaps = montarLinkGoogleMaps(loja_endereco || 'origem', destinos);
    const linkWaze = montarLinkWaze(destinos[0]);

    // Cria a rota no banco
    const { data: rota, error: erroRota } = await supabase.from('rotas').insert({
      entregador_id,
      pedidos_ids: pedidosOrdenados.map(p => p.id),
      total_pedidos: pedidosOrdenados.length,
      link_google_maps: linkGoogleMaps,
      link_waze: linkWaze,
      status: 'pendente',
      valor_total_taxas: pedidosOrdenados.length * 4.50
    }).select().single();

    if (erroRota) return res.status(400).json({ erro: erroRota.message });

    // Atualiza status dos pedidos para 'aceito'
    await supabase.from('pedidos')
      .update({ status: 'aceito', aceito_em: new Date().toISOString() })
      .in('id', pedidos_ids);

    // Atualiza status do entregador
    await supabase.from('entregadores')
      .update({ status: 'em_rota' }).eq('id', entregador_id);

    res.status(201).json({
      rota,
      link_google_maps: linkGoogleMaps,
      link_waze: linkWaze,
      mensagem: `✅ Rota com ${pedidosOrdenados.length} entrega(s) montada!`,
      pedidos: pedidosOrdenados.map((p, i) => ({
        ordem: i + 1,
        id: p.id,
        cliente: p.cliente_nome,
        endereco: p.cliente_endereco,
        codigo_confirmacao: p.codigo_confirmacao
      }))
    });
  } catch (e) {
    res.status(500).json({ erro: e.message });
  }
});

// GET /api/rotas - lista rotas
router.get('/', auth, async (req, res) => {
  try {
    const { status, entregador_id } = req.query;
    let query = supabase
      .from('rotas')
      .select('*, entregadores(nome, telefone), lojas(nome)')
      .order('created_at', { ascending: false });

    if (status) query = query.eq('status', status);
    if (entregador_id) query = query.eq('entregador_id', entregador_id);

    const { data, error } = await query;
    if (error) return res.status(400).json({ erro: error.message });
    res.json(data);
  } catch (e) {
    res.status(500).json({ erro: e.message });
  }
});

// PATCH /api/rotas/:id/iniciar
router.patch('/:id/iniciar', auth, async (req, res) => {
  try {
    const { data, error } = await supabase.from('rotas')
      .update({ status: 'em_andamento', iniciada_em: new Date().toISOString() })
      .eq('id', req.params.id).select().single();
    if (error) return res.status(400).json({ erro: error.message });
    res.json({ mensagem: '🛵 Rota iniciada!', rota: data });
  } catch (e) {
    res.status(500).json({ erro: e.message });
  }
});

// PATCH /api/rotas/:id/concluir
router.patch('/:id/concluir', auth, async (req, res) => {
  try {
    const { data: rota } = await supabase.from('rotas').select('*').eq('id', req.params.id).single();

    await supabase.from('rotas').update({
      status: 'concluida', concluida_em: new Date().toISOString()
    }).eq('id', req.params.id);

    // Deixa entregador disponível novamente
    await supabase.from('entregadores')
      .update({ status: 'disponivel' }).eq('id', rota.entregador_id);

    res.json({ mensagem: '✅ Rota concluída!' });
  } catch (e) {
    res.status(500).json({ erro: e.message });
  }
});

module.exports = router;
