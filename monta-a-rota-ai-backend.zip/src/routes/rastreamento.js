const { rastreamentoRouter } = require('./outros');
module.exports = rastreamentoRouter;
