const { lojasRouter } = require('./outros');
module.exports = lojasRouter;
