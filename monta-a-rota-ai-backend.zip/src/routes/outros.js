// ============================================================
// LOJAS
// ============================================================
const express = require('express');
const supabase = require('../config/supabase');
const auth = require('../middleware/auth');

const lojasRouter = express.Router();

lojasRouter.get('/', auth, async (req, res) => {
  const { data, error } = await supabase.from('lojas').select('*').eq('status', 'ativo').order('nome');
  if (error) return res.status(400).json({ erro: error.message });
  res.json(data);
});

lojasRouter.get('/:id', auth, async (req, res) => {
  const { data, error } = await supabase.from('lojas').select('*').eq('id', req.params.id).single();
  if (error) return res.status(404).json({ erro: 'Loja não encontrada' });
  res.json(data);
});

lojasRouter.post('/', auth, async (req, res) => {
  const { nome, cnpj, telefone, endereco, bairro, cidade, cep, taxa_fixa, email, contato_nome } = req.body;
  if (!nome) return res.status(400).json({ erro: 'Nome obrigatório' });
  const { data, error } = await supabase.from('lojas').insert({
    nome, cnpj, telefone, endereco, bairro, cidade, cep,
    taxa_fixa: taxa_fixa || 4.50, email, contato_nome
  }).select().single();
  if (error) return res.status(400).json({ erro: error.message });
  res.status(201).json(data);
});

lojasRouter.put('/:id', auth, async (req, res) => {
  const { data, error } = await supabase.from('lojas').update(req.body).eq('id', req.params.id).select().single();
  if (error) return res.status(400).json({ erro: error.message });
  res.json(data);
});

module.exports.lojasRouter = lojasRouter;

// ============================================================
// PAGAMENTOS
// ============================================================
const pagamentosRouter = express.Router();

pagamentosRouter.get('/', auth, async (req, res) => {
  const { loja_id, entregador_id, status } = req.query;
  let query = supabase.from('pagamentos').select('*, lojas(nome), entregadores(nome)').order('created_at', { ascending: false });
  if (loja_id) query = query.eq('loja_id', loja_id);
  if (entregador_id) query = query.eq('entregador_id', entregador_id);
  if (status) query = query.eq('status', status);
  const { data, error } = await query;
  if (error) return res.status(400).json({ erro: error.message });
  res.json(data);
});

// Gera cobrança semanal automática para uma loja
pagamentosRouter.post('/gerar-semanal', auth, async (req, res) => {
  try {
    const { loja_id, periodo_inicio, periodo_fim } = req.body;

    // Conta pedidos entregues no período
    const { data: pedidos } = await supabase
      .from('pedidos')
      .select('id, taxa_plataforma')
      .eq('loja_id', loja_id)
      .eq('status', 'entregue')
      .gte('created_at', `${periodo_inicio}T00:00:00`)
      .lte('created_at', `${periodo_fim}T23:59:59`);

    const total_entregas = pedidos?.length || 0;
    const valor_bruto = pedidos?.reduce((sum, p) => sum + (p.taxa_plataforma || 4.50), 0) || 0;

    const { data, error } = await supabase.from('pagamentos').insert({
      tipo: 'loja_para_plataforma',
      loja_id, periodo_inicio, periodo_fim,
      total_entregas, valor_bruto, valor_liquido: valor_bruto,
      status: 'pendente'
    }).select().single();

    if (error) return res.status(400).json({ erro: error.message });
    res.status(201).json({ ...data, mensagem: `💰 Cobrança gerada: ${total_entregas} entregas = R$ ${valor_bruto.toFixed(2)}` });
  } catch (e) {
    res.status(500).json({ erro: e.message });
  }
});

pagamentosRouter.patch('/:id/pagar', auth, async (req, res) => {
  const { metodo_pagamento, comprovante_url } = req.body;
  const { data, error } = await supabase.from('pagamentos').update({
    status: 'pago', metodo_pagamento, comprovante_url, pago_em: new Date().toISOString()
  }).eq('id', req.params.id).select().single();
  if (error) return res.status(400).json({ erro: error.message });
  res.json({ mensagem: '✅ Pagamento registrado!', pagamento: data });
});

module.exports.pagamentosRouter = pagamentosRouter;

// ============================================================
// RASTREAMENTO GPS
// ============================================================
const rastreamentoRouter = express.Router();

rastreamentoRouter.get('/entregador/:id', auth, async (req, res) => {
  const { data, error } = await supabase
    .from('rastreamento_gps')
    .select('lat, lng, created_at, velocidade_kmh')
    .eq('entregador_id', req.params.id)
    .order('created_at', { ascending: false })
    .limit(100);
  if (error) return res.status(400).json({ erro: error.message });
  res.json(data);
});

module.exports.rastreamentoRouter = rastreamentoRouter;

// ============================================================
// ANALYTICS
// ============================================================
const analyticsRouter = express.Router();

analyticsRouter.get('/resumo/:loja_id', auth, async (req, res) => {
  try {
    const { loja_id } = req.params;
    const hoje = new Date().toISOString().split('T')[0];
    const inicioMes = hoje.substring(0, 7) + '-01';

    const { data: pedidosHoje } = await supabase
      .from('pedidos').select('id, valor_pedido, taxa_plataforma, cliente_bairro')
      .eq('loja_id', loja_id).eq('status', 'entregue')
      .gte('created_at', `${hoje}T00:00:00`);

    const { data: pedidosMes } = await supabase
      .from('pedidos').select('id, valor_pedido, taxa_plataforma')
      .eq('loja_id', loja_id).eq('status', 'entregue')
      .gte('created_at', `${inicioMes}T00:00:00`);

    // Bairros mais frequentes
    const bairros = {};
    pedidosHoje?.forEach(p => {
      if (p.cliente_bairro) bairros[p.cliente_bairro] = (bairros[p.cliente_bairro] || 0) + 1;
    });
    const topBairros = Object.entries(bairros).sort((a, b) => b[1] - a[1]).slice(0, 5);

    res.json({
      hoje: {
        total_pedidos: pedidosHoje?.length || 0,
        receita_taxa: pedidosHoje?.reduce((s, p) => s + (p.taxa_plataforma || 4.50), 0) || 0
      },
      mes: {
        total_pedidos: pedidosMes?.length || 0,
        receita_taxa: pedidosMes?.reduce((s, p) => s + (p.taxa_plataforma || 4.50), 0) || 0
      },
      top_bairros: topBairros.map(([bairro, total]) => ({ bairro, total })),
      sugestao: topBairros.length > 0
        ? `🎯 Foque marketing no bairro ${topBairros[0][0]} — ${topBairros[0][1]} entregas hoje`
        : 'Sem dados suficientes ainda'
    });
  } catch (e) {
    res.status(500).json({ erro: e.message });
  }
});

module.exports.analyticsRouter = analyticsRouter;

// ============================================================
// OCR (simulado — integração real com Google Vision na v2)
// ============================================================
const ocrRouter = express.Router();

ocrRouter.post('/processar', auth, async (req, res) => {
  try {
    const { foto_url, loja_id, texto_bruto } = req.body;

    // Extração básica via regex do texto OCR
    const extrairTelefone = (txt) => (txt.match(/\(?\d{2}\)?\s?\d{4,5}[-\s]?\d{4}/) || [])[0] || null;
    const extrairCEP = (txt) => (txt.match(/\d{5}-?\d{3}/) || [])[0] || null;
    const extrairValor = (txt) => {
      const match = txt.match(/R\$\s?(\d+[.,]\d{2})/);
      return match ? parseFloat(match[1].replace(',', '.')) : null;
    };

    const dados = {
      cliente_telefone: extrairTelefone(texto_bruto || ''),
      cliente_cep: extrairCEP(texto_bruto || ''),
      valor_pedido: extrairValor(texto_bruto || ''),
      texto_bruto,
      confianca_ocr: 0.75 // 75% de confiança (placeholder)
    };

    // Salva no banco
    const { data, error } = await supabase.from('comandas_ocr').insert({
      loja_id, foto_url: foto_url || 'pendente', texto_bruto,
      ...dados, confirmado: false
    }).select().single();

    if (error) return res.status(400).json({ erro: error.message });
    res.json({ ...data, mensagem: '📸 Comanda processada! Revise os dados antes de confirmar.' });
  } catch (e) {
    res.status(500).json({ erro: e.message });
  }
});

module.exports.ocrRouter = ocrRouter;
