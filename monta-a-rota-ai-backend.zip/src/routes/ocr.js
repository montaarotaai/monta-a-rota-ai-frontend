const { ocrRouter } = require('./outros');
module.exports = ocrRouter;
