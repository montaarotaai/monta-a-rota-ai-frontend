// ============================================================
// 🚀 MONTA A ROTA AÍ - Servidor Principal
// ============================================================
require('dotenv').config();
const express = require('express');
const cors = require('cors');

const app = express();
const PORT = process.env.PORT || 3000;

// ===== MIDDLEWARES =====
app.use(cors({ origin: '*' }));
app.use(express.json({ limit: '10mb' })); // limite maior para fotos de comanda
app.use(express.urlencoded({ extended: true }));

// ===== ROTAS DA API =====
app.use('/api/auth',        require('./routes/auth'));
app.use('/api/lojas',       require('./routes/lojas'));
app.use('/api/entregadores',require('./routes/entregadores'));
app.use('/api/pedidos',     require('./routes/pedidos'));
app.use('/api/rotas',       require('./routes/rotas'));
app.use('/api/pagamentos',  require('./routes/pagamentos'));
app.use('/api/ocr',         require('./routes/ocr'));
app.use('/api/rastreamento',require('./routes/rastreamento'));
app.use('/api/analytics',   require('./routes/analytics'));

// ===== HEALTH CHECK (Railway usa isso para saber se está vivo) =====
app.get('/', (req, res) => {
  res.json({
    sistema: '🚀 Monta a Rota Aí - API',
    status: 'online',
    versao: '1.0.0',
    timestamp: new Date().toISOString()
  });
});

app.get('/health', (req, res) => {
  res.json({ status: 'ok', uptime: process.uptime() });
});

// ===== ERRO 404 =====
app.use((req, res) => {
  res.status(404).json({ erro: 'Rota não encontrada' });
});

// ===== ERRO GERAL =====
app.use((err, req, res, next) => {
  console.error('❌ Erro:', err.message);
  res.status(500).json({ erro: 'Erro interno do servidor', detalhe: err.message });
});

// ===== INICIAR SERVIDOR =====
app.listen(PORT, () => {
  console.log(`✅ Monta a Rota Aí rodando na porta ${PORT}`);
  console.log(`📡 Ambiente: ${process.env.NODE_ENV || 'development'}`);
});

module.exports = app;
