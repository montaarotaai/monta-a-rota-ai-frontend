// Gera código de confirmação de 6 dígitos (anti-fraude)
function gerarCodigoConfirmacao() {
  return Math.floor(100000 + Math.random() * 900000).toString();
}

// Calcula previsão de entrega (agora + tempo preparo + 20min entrega)
function calcularPrevisaoEntrega(tempoPreparo = 20, tempoEntregaMin = 20) {
  const agora = new Date();
  agora.setMinutes(agora.getMinutes() + tempoPreparo + tempoEntregaMin);
  return agora.toISOString();
}

// Verifica se pedido está em risco de atraso
function verificarRiscoAtraso(previsaoEntrega, status) {
  if (['entregue', 'cancelado'].includes(status)) return false;
  const agora = new Date();
  const previsao = new Date(previsaoEntrega);
  const diff = (previsao - agora) / 60000; // diferença em minutos
  return diff < 10; // risco se menos de 10 min para o prazo
}

// Formata valor em BRL
function formatarMoeda(valor) {
  return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(valor || 0);
}

module.exports = { gerarCodigoConfirmacao, calcularPrevisaoEntrega, verificarRiscoAtraso, formatarMoeda };
